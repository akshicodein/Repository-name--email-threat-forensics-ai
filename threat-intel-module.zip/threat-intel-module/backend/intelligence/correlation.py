"""Threat Memory lookups + Attack DNA similarity + campaign correlation.

Reminder (team rules): similarity/relationship results are investigation
signals, never framed as "confirmed same attacker".
"""

import difflib
from backend.intelligence import db
from backend.intelligence.config import settings
from backend.intelligence.models import RelatedCase, CampaignResult


def dna_similarity(dna_a: str, dna_b: str) -> float:
    if not dna_a or not dna_b:
        return 0.0
    return difflib.SequenceMatcher(None, dna_a, dna_b).ratio()


def find_related_cases(
    case_id: str, ips: list[str], domains: list[str], attack_dna: str | None
) -> list[RelatedCase]:
    related: dict[str, RelatedCase] = {}

    for ip in ips:
        for cid in db.find_cases_by_ip(ip, exclude_case_id=case_id):
            r = related.setdefault(cid, RelatedCase(case_id=cid, shared_indicators=[]))
            r.shared_indicators.append(f"ip:{ip}")

    for domain in domains:
        for cid in db.find_cases_by_domain(domain, exclude_case_id=case_id):
            r = related.setdefault(cid, RelatedCase(case_id=cid, shared_indicators=[]))
            r.shared_indicators.append(f"domain:{domain}")

    if attack_dna:
        for historical in db.all_cases(exclude_case_id=case_id):
            sim = dna_similarity(attack_dna, historical.get("attack_dna") or "")
            if sim >= settings.DNA_SIMILARITY_THRESHOLD:
                r = related.setdefault(
                    historical["case_id"],
                    RelatedCase(case_id=historical["case_id"], shared_indicators=[]),
                )
                r.similarity = sim
                r.shared_indicators.append("attack_dna")

    return list(related.values())


def correlate_campaign(related_cases: list[RelatedCase]) -> CampaignResult:
    if not related_cases:
        return CampaignResult(confidence=0.0, summary="No related infrastructure found in Threat Memory.")

    scored = []
    for rc in related_cases:
        weight = 0.3 * len(rc.shared_indicators)
        if rc.similarity:
            weight += rc.similarity * 0.6
        scored.append((rc.case_id, min(weight, 1.0)))

    scored.sort(key=lambda x: x[1], reverse=True)
    top_confidence = scored[0][1] if scored else 0.0

    if top_confidence < settings.CAMPAIGN_CONFIDENCE_THRESHOLD:
        return CampaignResult(
            confidence=round(top_confidence, 2),
            related_case_ids=[c for c, _ in scored],
            summary="Weak overlap with prior cases — insufficient for a campaign designation.",
        )

    campaign_id = f"CAMPAIGN-{scored[0][0]}"
    return CampaignResult(
        possible_campaign=campaign_id,
        confidence=round(top_confidence, 2),
        related_case_ids=[c for c, _ in scored],
        summary=(
            "Possible campaign relationship based on shared infrastructure and/or "
            "Attack DNA similarity. This is an investigation signal, not confirmation "
            "of a single attacker."
        ),
    )
