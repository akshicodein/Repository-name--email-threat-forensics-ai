"""Domain enrichment: DNS, MX, nameservers, RDAP registration data."""

import httpx
from datetime import datetime, timezone
import dns.resolver
from backend.intelligence.models import DomainIntelligence

NEWLY_REGISTERED_DAYS = 30


def _resolve(domain: str, record_type: str) -> list[str]:
    try:
        answers = dns.resolver.resolve(domain, record_type, lifetime=5.0)
        return [str(r).rstrip(".") for r in answers]
    except Exception:
        return []


def _rdap_lookup(domain: str) -> dict:
    try:
        resp = httpx.get(f"https://rdap.org/domain/{domain}", timeout=6.0, follow_redirects=True)
        if resp.status_code != 200:
            return {}
        return resp.json()
    except Exception:
        return {}


def _extract_registrar(rdap: dict) -> str | None:
    for entity in rdap.get("entities", []):
        if "registrar" in entity.get("roles", []):
            vcard = entity.get("vcardArray")
            if vcard and len(vcard) > 1:
                for field in vcard[1]:
                    if field[0] == "fn":
                        return field[3]
    return None


def _extract_created_date(rdap: dict) -> str | None:
    for event in rdap.get("events", []):
        if event.get("eventAction") == "registration":
            return event.get("eventDate")
    return None


def enrich_domain(domain: str) -> DomainIntelligence:
    a = _resolve(domain, "A")
    aaaa = _resolve(domain, "AAAA")
    mx = _resolve(domain, "MX")
    ns = _resolve(domain, "NS")

    rdap = _rdap_lookup(domain)
    registrar = _extract_registrar(rdap)
    created = _extract_created_date(rdap)

    is_new = None
    if created:
        try:
            created_dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
            is_new = (datetime.now(timezone.utc) - created_dt).days < NEWLY_REGISTERED_DAYS
        except Exception:
            is_new = None

    flags = []
    if is_new:
        flags.append("newly_registered")
    if not mx:
        flags.append("no_mx_record")
    if not a and not aaaa:
        flags.append("no_resolvable_address")

    return DomainIntelligence(
        domain=domain,
        a_records=a,
        aaaa_records=aaaa,
        mx_records=mx,
        nameservers=ns,
        registrar=registrar,
        created_date=created,
        is_newly_registered=is_new,
        reputation="unknown",
        flags=flags,
    )


def enrich_domains(domains: list[str]) -> list[DomainIntelligence]:
    return [enrich_domain(d) for d in dict.fromkeys(domains)]
